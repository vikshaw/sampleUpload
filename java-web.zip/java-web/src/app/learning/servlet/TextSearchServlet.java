package app.learning.servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class TextSearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Inside Get servlet");
		RequestDispatcher rd = request.getRequestDispatcher("textSearchForm.jsp");
		rd.forward(request, response);
	}
	
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Inside Servlet post call**************");
		String fileNeed = request.getParameter("file");
		String input = request.getParameter("input");
		System.out.println("Got filename:" + fileNeed);
		System.out.println("Got input:" + input);
		
		
		String[] words = null;
		FileReader fileReader = new FileReader(fileNeed);
		BufferedReader bufferReader = new BufferedReader(fileReader);
		String search;
		int lineCount = 0, totalWords = 0;
		int count = 0;
		while((search = bufferReader.readLine()) != null) {
			words=search.split(" ");
			for (String word : words) 
	          {
	                 if (word.equals(input))  
	                 {
	                   count++;   
	                 }
	                 totalWords=totalWords+words.length;
	          }
			lineCount++;
		}
		System.out.println("**************Got count = "+ count);
		if(count != 0) {
			request.getRequestDispatcher("textSearchResult.jsp").forward(request, response);
		}else {
			
		}
	}

}
